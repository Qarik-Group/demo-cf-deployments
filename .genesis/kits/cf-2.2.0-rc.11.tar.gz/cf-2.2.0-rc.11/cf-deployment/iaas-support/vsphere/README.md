# Deploying Cloud Foundry on Vsphere
**Note about support:** The Release Integration team does not maintain nor validate Vsphere deployments and Vsphere deployers must rely on the general CF community for support.

In this directory, we provide an example `cloud-config.yml` for Vsphere.  

For more information, see the [BOSH documentation](https://bosh.io/docs/init-vsphere.html).
